import java.sql.Connection;
import java.sql.SQLException;

import com.hpiinc.strutsExample.model.user;
import com.hpiinc.strutsExample.repository.UserRepository;
import com.hpiinc.strutsExample.util.ConnectionUtil;

public class Test {

	public static void main(String[] args) throws Exception, Exception {
	//	System.out.println(ConnectionUtil.getConnection().getDBConnection().isClosed());

		
//		Connection con=ConnectionUtil.getConnection().getDBConnection();
//		
		
//	boolean res=UserRepository.getRepository().add(new user("rushabh",9874561230l));
//		
//	System.out.println(res);
//		
		UserRepository.getRepository().getAllUsers().forEach(System.out::println);
		
		
	}

}
