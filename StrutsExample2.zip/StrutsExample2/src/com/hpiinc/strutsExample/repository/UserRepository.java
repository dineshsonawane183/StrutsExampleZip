package com.hpiinc.strutsExample.repository;

import java.util.List;

import com.hpiinc.strutsExample.dao.userDao;
import com.hpiinc.strutsExample.dao.userDaoImpl;
import com.hpiinc.strutsExample.model.user;



public class UserRepository  {

	public static  UserRepository userRepository;
	
	public static UserRepository getRepository() {
			userRepository=new UserRepository();
				return userRepository;
		
	}
	userDao userDao=new userDaoImpl();
	public boolean add(user u) throws Exception {
		return userDao.add(u);
	}

	public boolean update(user u) throws Exception {
		return false;
	}

	public boolean delete(user u) throws Exception {
		return false;
	}

	public List<user> getAllUsers() throws Exception {
		return userDao.getAllUsers();
	}

	public user getUserById(int id) throws Exception {
		return null;
	}


	

}
