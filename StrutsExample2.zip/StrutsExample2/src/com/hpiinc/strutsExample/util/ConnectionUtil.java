package com.hpiinc.strutsExample.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionUtil {

	private static ConnectionUtil connectionUtil;
	private ConnectionUtil() {
	super();
	}

	
	public static ConnectionUtil getConnection() {
		if(connectionUtil==null) {
			synchronized(ConnectionUtil.class) {
				if(connectionUtil==null) {
					connectionUtil=new ConnectionUtil();	
				}
			}
			
		}
		return connectionUtil;
	}
	
	public Connection getDBConnection() throws Exception {
	
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection con=DriverManager.getConnection("jdbc:mysql://192.168.225.33:3309/ankushdb", "root", "supra");
		return con;
	}
	
	
}
