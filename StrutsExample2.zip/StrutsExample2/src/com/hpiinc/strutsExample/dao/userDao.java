package com.hpiinc.strutsExample.dao;

import java.util.List;

import com.hpiinc.strutsExample.model.user;

public interface userDao {

boolean add(user u) throws Exception;	
boolean update(user u)throws Exception;	
boolean delete(user u)throws Exception;	
List<user> getAllUsers()throws Exception;	
user getUserById(int id)throws Exception;	
}
