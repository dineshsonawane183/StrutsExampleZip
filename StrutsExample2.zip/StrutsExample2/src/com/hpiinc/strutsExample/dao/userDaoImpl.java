package com.hpiinc.strutsExample.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.hpiinc.strutsExample.model.user;
import com.hpiinc.strutsExample.util.ConnectionUtil;

public class userDaoImpl implements userDao {

	private static final String ADD_USER = "insert into user (name,contact) values (?,?)";
	Connection con=null;
	@Override
	public boolean add(user u) {
		try {
			con=ConnectionUtil.getConnection().getDBConnection();
			PreparedStatement pst=con.prepareStatement(ADD_USER);
			pst.setString(1, u.getName());
			pst.setLong(2, u.getContact());
			int res=pst.executeUpdate();
			if(res>0) {
				return true;
			}
		}catch (Exception e) {
			return false;
		}
		
		return false;
	}

	@Override
	public boolean update(user u) {
		return false;
	}

	@Override
	public boolean delete(user u) {
		return false;
	}

	@Override
	public List<user> getAllUsers() throws Exception {
		con=ConnectionUtil.getConnection().getDBConnection();
		PreparedStatement pst=con.prepareStatement("select * from user");
		ResultSet rs=pst.executeQuery();
		
		List<user> users=new ArrayList<>();
		user u=null;
		while(rs.next()) {
			u=new user();
			u.setId(rs.getInt("id"));
			u.setName(rs.getString("name"));
			u.setContact(rs.getLong("contact"));
			users.add(u);
		}
		
		return users;
	}

	@Override
	public user getUserById(int id) {
		return null;
	}

}
