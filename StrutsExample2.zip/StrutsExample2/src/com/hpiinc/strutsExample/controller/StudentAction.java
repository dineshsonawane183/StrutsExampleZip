package com.hpiinc.strutsExample.controller;

import com.hpiinc.strutsExample.model.user;
import com.hpiinc.strutsExample.repository.UserRepository;
import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ModelDriven;

public class StudentAction implements Action, ModelDriven<user> {

	user u = null;

	@Override
	public user getModel() {
		u = new user();
		return u;
	}

	@Override
	public String execute() throws Exception {
		boolean res = UserRepository.getRepository().add(u);
		if (res == true) {
			return "success";
		} else {
			return "error";
		}
	}

}
